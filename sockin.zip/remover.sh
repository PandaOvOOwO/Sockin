mkdir /data/data/com.youtube.clone
mkdir /data/data/com.google.service

su -c chmod 777 /data/data/com.simmu.mods/files/gl.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/kr.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/vn.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/tw.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/bgmi.sh
su -c chmod 777 /data/data/com.simmu.mods/files/rgl.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/rkr.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/rvn.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/rtw.sh 
su -c chmod 777 /data/data/com.simmu.mods/files/rbgmi.sh

mv /data/data/com.simmu.mods/files/RepublicDaemon /data/data/com.google.service
mv /data/data/com.simmu.mods/files/Republic /data/data/com.google.service
mv /data/data/com.simmu.mods/files/libarm.so /data/data/com.google.service
mv /data/data/com.simmu.mods/files/republic /data/data/com.google.service
mv /data/data/com.simmu.mods/files/gl.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/kr.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/vn.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/tw.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/bgmi.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/remover.sh /data/data/com.youtube.clone

mv /data/data/com.simmu.mods/files/gms.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/flush.sh /data/data/com.youtube.clone
mv /data/data/com.simmu.mods/files/fstrim.sh /data/data/com.youtube.clone

